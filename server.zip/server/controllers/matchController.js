
const UserSkill = require("../models/UserSkill");

const findLearningMatches = async (req, res) => {
  try {
    const currentUserId = String(req.user.userId);

    // Find the skills the logged-in user wants to learn.
    const skillsToLearn = await UserSkill.find({
      user: currentUserId,
      type: "LEARN",
    }).populate("skill", "name category description");

    const skillIds = [
      ...new Set(
        skillsToLearn
          .filter((item) => item.skill)
          .map((item) => String(item.skill._id))
      ),
    ];

    if (skillIds.length === 0) {
      return res.status(200).json({
        matches: [],
        message: "Add some skills you want to learn first.",
      });
    }

    // Find other users who teach the requested skills.
    const matchingSkills = await UserSkill.find({
      user: { $ne: currentUserId },
      skill: { $in: skillIds },
      type: "TEACH",
    })
      .populate("user", "name bio avatar languages")
      .populate("skill", "name category description")
      .lean();

    // Group matching skills by teacher, ensuring each teacher
    // appears once with their matching skills.
    const teachersById = new Map();

    for (const item of matchingSkills) {
      if (!item.user || !item.skill) continue;

      const teacherId = String(item.user._id);

      // Extra safeguard: never include the current user.
      if (teacherId === currentUserId) continue;

      if (!teachersById.has(teacherId)) {
        teachersById.set(teacherId, {
          _id: teacherId,
          user: item.user,
          skills: [],
        });
      }

      const teacher = teachersById.get(teacherId);
      const skillId = String(item.skill._id);

      const alreadyIncluded = teacher.skills.some(
        (skill) => String(skill._id) === skillId
      );

      if (!alreadyIncluded) {
        teacher.skills.push(item.skill);
      }
    }

    return res.status(200).json({
      matches: Array.from(teachersById.values()),
    });
  } catch (error) {
    console.error("Find learning matches error:", error);

    return res.status(500).json({
      message: "Server error while finding matches",
    });
  }
};

module.exports = {
  findLearningMatches,
};
