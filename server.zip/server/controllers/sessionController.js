const mongoose = require("mongoose");
const Session = require("../models/Session");
const User = require("../models/User");
const Skill = require("../models/Skill");
const UserSkill = require("../models/UserSkill");

// Helper to extract the logged-in user's ID
const getCurrentUserId = (req) => req.user?.userId || req.user?._id;

// Helper to populate session participants and skill
const populateSessionQuery = (query) =>
  query
    .populate("teacher", "name avatar email timeCredits")
    .populate("learner", "name avatar email timeCredits")
    .populate("skill", "name category description");

// GET /api/sessions - Get sessions for the logged-in user
const getMySessions = async (req, res, next) => {
  try {
    const currentUserId = getCurrentUserId(req);

    if (!currentUserId) {
      return res.status(401).json({
        success: false,
        message: "Not authorized. User ID missing from token.",
      });
    }

    const sessions = await populateSessionQuery(
      Session.find({
        $or: [{ teacher: currentUserId }, { learner: currentUserId }],
      }).sort({ createdAt: -1 })
    );

    return res.status(200).json({
      success: true,
      count: sessions.length,
      sessions,
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/sessions/:id - Get a single session by ID
const getSessionById = async (req, res, next) => {
  try {
    const session = await populateSessionQuery(
      Session.findById(req.params.id)
    );

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session not found",
      });
    }

    const userId = String(getCurrentUserId(req));
    const teacherId = String(session.teacher._id || session.teacher);
    const learnerId = String(session.learner._id || session.learner);

    if (
      userId !== teacherId &&
      userId !== learnerId &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({
        success: false,
        message: "Not authorized to view this session",
      });
    }

    return res.status(200).json({
      success: true,
      session,
    });
  } catch (error) {
    next(error);
  }
};

// POST /api/sessions/request - Request a learning session
const createSessionRequest = async (req, res, next) => {
  try {
    const currentUserId = getCurrentUserId(req);
    const {
      teacherId,
      skillId,
      duration = 1,
      message = "",
      notes = "",
    } = req.body;

    if (!currentUserId) {
      return res.status(401).json({
        success: false,
        message: "Not authorized. User ID missing from token.",
      });
    }

    if (!teacherId || !skillId) {
      return res.status(400).json({
        success: false,
        message: "Teacher ID and skill ID are required",
      });
    }

    const finalLearnerId = String(currentUserId);
    const finalTeacherId = String(teacherId);

    if (finalLearnerId === finalTeacherId) {
      return res.status(400).json({
        success: false,
        message: "You cannot request a session with yourself",
      });
    }

    const sessionDuration = Number(duration);
    if (
      !Number.isInteger(sessionDuration) ||
      sessionDuration < 1 ||
      sessionDuration > 4
    ) {
      return res.status(400).json({
        success: false,
        message: "Session duration must be an integer between 1 and 4 hours",
      });
    }

    const [learner, teacher, skill] = await Promise.all([
      User.findById(finalLearnerId),
      User.findById(finalTeacherId),
      Skill.findById(skillId),
    ]);

    if (!learner) {
      return res.status(404).json({
        success: false,
        message: "Learner account not found",
      });
    }

    if (!teacher) {
      return res.status(404).json({
        success: false,
        message: "Teacher account not found",
      });
    }

    if (!skill) {
      return res.status(404).json({
        success: false,
        message: "Skill not found",
      });
    }

    // Verify learner has sufficient time credits
    if (learner.timeCredits < sessionDuration) {
      return res.status(400).json({
        success: false,
        message: `You need ${sessionDuration} time credit(s) for this session, but you currently have ${learner.timeCredits}.`,
      });
    }

    // Verify teacher offers to teach this skill
    const teacherTeachesSkill = await UserSkill.findOne({
      user: finalTeacherId,
      skill: skillId,
      type: "TEACH",
    });

    if (!teacherTeachesSkill) {
      return res.status(400).json({
        success: false,
        message: "The requested user does not teach this skill",
      });
    }

    // Prevent duplicate pending requests for the same pair and skill
    const existingPending = await Session.findOne({
      learner: finalLearnerId,
      teacher: finalTeacherId,
      skill: skillId,
      status: "PENDING",
    });

    if (existingPending) {
      return res.status(409).json({
        success: false,
        message: "You already have a pending session request for this skill with this teacher",
      });
    }

    const session = await Session.create({
      learner: finalLearnerId,
      teacher: finalTeacherId,
      skill: skillId,
      duration: sessionDuration,
      credits: sessionDuration,
      message: (message || notes || "").trim().slice(0, 500),
      status: "PENDING",
    });

    const populatedSession = await populateSessionQuery(
      Session.findById(session._id)
    );

    return res.status(201).json({
      success: true,
      message: "Session request sent successfully",
      session: populatedSession,
    });
  } catch (error) {
    next(error);
  }
};

// PATCH /api/sessions/:id/accept - Teacher accepts a pending session request
const acceptSessionRequest = async (req, res, next) => {
  try {
    const currentUserId = String(getCurrentUserId(req));
    const session = await Session.findById(req.params.id);

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session request not found",
      });
    }

    if (String(session.teacher) !== currentUserId) {
      return res.status(403).json({
        success: false,
        message: "Only the teacher can accept this request",
      });
    }

    if (session.status !== "PENDING") {
      return res.status(400).json({
        success: false,
        message: `Cannot accept a session with status "${session.status}". Only pending sessions can be accepted.`,
      });
    }

    const { meetingLink } = req.body || {};
    if (meetingLink && typeof meetingLink === "string") {
      session.meetingLink = meetingLink.trim();
    }

    session.status = "ACCEPTED";
    await session.save();

    const populated = await populateSessionQuery(
      Session.findById(session._id)
    );

    return res.status(200).json({
      success: true,
      message: "Session request accepted successfully",
      session: populated,
    });
  } catch (error) {
    next(error);
  }
};

// PATCH /api/sessions/:id/reject - Teacher rejects a pending session request
const rejectSessionRequest = async (req, res, next) => {
  try {
    const currentUserId = String(getCurrentUserId(req));
    const session = await Session.findById(req.params.id);

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session request not found",
      });
    }

    if (String(session.teacher) !== currentUserId) {
      return res.status(403).json({
        success: false,
        message: "Only the teacher can reject this request",
      });
    }

    if (session.status !== "PENDING") {
      return res.status(400).json({
        success: false,
        message: `Cannot reject a session with status "${session.status}". Only pending sessions can be rejected.`,
      });
    }

    session.status = "REJECTED";
    await session.save();

    const populated = await populateSessionQuery(
      Session.findById(session._id)
    );

    return res.status(200).json({
      success: true,
      message: "Session request rejected",
      session: populated,
    });
  } catch (error) {
    next(error);
  }
};

// PATCH /api/sessions/:id/complete - Confirm and complete session with credit transfer
const completeSession = async (req, res, next) => {
  try {
    const currentUserId = String(getCurrentUserId(req));
    const session = await Session.findById(req.params.id);

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session not found",
      });
    }

    const isTeacher = String(session.teacher) === currentUserId;
    const isLearner = String(session.learner) === currentUserId;

    if (!isTeacher && !isLearner && req.user.role !== "admin") {
      return res.status(403).json({
        success: false,
        message: "Only participants in this session can confirm completion",
      });
    }

    if (session.status === "COMPLETED") {
      return res.status(400).json({
        success: false,
        message: "This session has already been completed",
      });
    }

    if (session.status !== "ACCEPTED") {
      return res.status(400).json({
        success: false,
        message: `Only accepted sessions can be completed. Current status: ${session.status}`,
      });
    }

    // Record individual confirmation timestamps
    const now = new Date();
    if (isTeacher) {
      session.teacherConfirmedAt = session.teacherConfirmedAt || now;
    }
    if (isLearner) {
      session.learnerConfirmedAt = session.learnerConfirmedAt || now;
    }

    const bothConfirmed =
      Boolean(session.teacherConfirmedAt) && Boolean(session.learnerConfirmedAt);

    if (bothConfirmed) {
      // Both participants have confirmed: finalize completion and transfer credits
      const credits = session.credits;

      // Transfer credits with transaction or atomic fallback
      const dbSession = await mongoose.startSession().catch(() => null);

      if (dbSession) {
        try {
          await dbSession.withTransaction(async () => {
            const learner = await User.findById(session.learner).session(dbSession);
            const teacher = await User.findById(session.teacher).session(dbSession);

            if (!learner || !teacher) {
              const err = new Error("Learner or teacher account not found");
              err.statusCode = 404;
              throw err;
            }

            if (learner.timeCredits < credits) {
              const err = new Error("Learner does not have enough time credits to complete transfer");
              err.statusCode = 400;
              throw err;
            }

            learner.timeCredits -= credits;
            teacher.timeCredits += credits;

            await learner.save({ session: dbSession });
            await teacher.save({ session: dbSession });

            session.status = "COMPLETED";
            session.completedAt = now;
            await session.save({ session: dbSession });
          });
        } finally {
          await dbSession.endSession();
        }
      } else {
        // Fallback for standalone MongoDB instances without replica sets
        const learner = await User.findById(session.learner);
        const teacher = await User.findById(session.teacher);

        if (!learner || !teacher) {
          return res.status(404).json({
            success: false,
            message: "Learner or teacher account not found",
          });
        }

        if (learner.timeCredits < credits) {
          return res.status(400).json({
            success: false,
            message: "Learner does not have enough time credits",
          });
        }

        learner.timeCredits -= credits;
        teacher.timeCredits += credits;

        await learner.save();
        await teacher.save();

        session.status = "COMPLETED";
        session.completedAt = now;
        await session.save();
      }

      const populated = await populateSessionQuery(
        Session.findById(session._id)
      );

      return res.status(200).json({
        success: true,
        message: "Session completed and credits transferred successfully!",
        session: populated,
      });
    }

    // Only one party has confirmed so far
    await session.save();

    const populated = await populateSessionQuery(
      Session.findById(session._id)
    );

    return res.status(200).json({
      success: true,
      message: isTeacher
        ? "Teacher completion confirmed. Waiting for the learner to confirm."
        : "Learner completion confirmed. Waiting for the teacher to confirm.",
      session: populated,
    });
  } catch (error) {
    next(error);
  }
};

// PATCH /api/sessions/:id/cancel - Cancel a session
const cancelSession = async (req, res, next) => {
  try {
    const currentUserId = String(getCurrentUserId(req));
    const { reason = "" } = req.body || {};
    const session = await Session.findById(req.params.id);

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session not found",
      });
    }

    const isTeacher = String(session.teacher) === currentUserId;
    const isLearner = String(session.learner) === currentUserId;

    if (!isTeacher && !isLearner && req.user.role !== "admin") {
      return res.status(403).json({
        success: false,
        message: "Not authorized to cancel this session",
      });
    }

    if (["COMPLETED", "CANCELLED", "REJECTED"].includes(session.status)) {
      return res.status(409).json({
        success: false,
        message: `Cannot cancel a session that is already ${session.status.toLowerCase()}`,
      });
    }

    session.status = "CANCELLED";
    session.cancelledAt = new Date();
    session.cancelledBy = currentUserId;
    session.cancellationReason =
      typeof reason === "string" ? reason.trim().slice(0, 500) : "Cancelled by participant";

    await session.save();

    const populated = await populateSessionQuery(
      Session.findById(session._id)
    );

    return res.status(200).json({
      success: true,
      message: "Session cancelled successfully",
      session: populated,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getMySessions,
  getSessionById,
  createSessionRequest,
  acceptSessionRequest,
  rejectSessionRequest,
  completeSession,
  cancelSession,
};