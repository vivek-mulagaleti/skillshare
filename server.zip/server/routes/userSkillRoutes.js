
const express = require("express");
const protect = require("../middleware/authMiddleware");

const {
  addUserSkill,
  getMySkills,
  getTeachingSkillsByUserId,
} = require("../controllers/userSkillController");

const router = express.Router();

router.get("/my-skills", protect, getMySkills);
router.get("/teacher/:userId", protect, getTeachingSkillsByUserId);
router.post("/", protect, addUserSkill);

module.exports = router;
